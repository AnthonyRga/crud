<?php

try{
    // se connecter en local ->
    // $db = new PDO('mysql:host=localhost;dbname=regaia', 'root', 'root');

    $db = new PDO('mysql:host=localhost;dbname=regaia;', 'regaia', '4qyk0I4p');
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e){

}

function formPresentation($db){
    //image me.jpg
    $requestImage='SELECT nom_dossier,nom_fichier,extension FROM `image` where position ="presentation" ';
    $reponseImage=crudDb($db,$requestImage);
    $lineImage=$reponseImage->fetchAll();

    $j=0;
    // concaténation du content
    $content2 = '';

    for($i=0;$i<count($lineImage);$i++){
        $content2 .='<div class="margin1">';
        $content2 .='<img class="border-radius" src="';
        $content2 .= $lineImage[$i]['nom_dossier'].'/'.$lineImage[$i]['nom_fichier'].'.'.$lineImage[$i]['extension'];
        $content2 .= '" alt="#" width="250" height="250"> ';
        $content2 .='</div>';
        $j++;
        
    }

    //mon âge
    $requestAge='SELECT age FROM `age`';
    $reponse=crudDb($db,$requestAge);
    $lineAge=$reponse->fetch();

    //ma commune
    $requestCommune='SELECT commune FROM `commune`';
    $reponse=crudDb($db,$requestCommune);
    $lineCommune=$reponse->fetch();

    //présentation
    $requestPresentation='SELECT presentation FROM `presentation`';
    $reponse=crudDb($db,$requestPresentation);
    $linePresentation=$reponse->fetch();



    //email perso footer
    $requestMail= 'SELECT personnel from `personnel`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $mail=$linemail['personnel'];

    //linkedin footer
    $requestMail= 'SELECT linkedin from `linkedin`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $linkedin=$linemail['linkedin'];


    //facebook footer
    $requestMail= 'SELECT facebook from `facebook`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $facebook=$linemail['facebook'];

    //les hobbys
    $requestSelect='SELECT hobbys FROM `hobbys`';
    $reponseSelect=crudDb($db,$requestSelect);
    $lines = $reponseSelect->fetchAll();
    $content = '';
    foreach($lines as $line){
        $content .=  '<p><i class="fas fa-circle"></i>'. $line['hobbys'].'</p>';

    }
    $content .=' 
    <div class="clear"></div>';


echo '

<section>
    <div class="container">
        <div class="col col-1-3">
            '.$content2.' 
        </div>
        <div class="col col-1-6 last">
            <p>Je m\'appelle Anthony Regaia, j\'ai '.$lineAge['age'].' ans.</p>
            <p>J\'habite actuellement dans la commune de '.$lineCommune['commune'].'</p>
            <p>'.$linePresentation['presentation'].'</p>
        </div>
            <div class="col col-1-6bis last">
                <p>J\'ai quelques passions et hobbys :<br>
                <p> '.$content.' </p>
            </div>
            <div class="clear"></div>                           
    </div>
</section>

<footer id="presentation">   
    <div class="container">       
        <a class="alink" href="mailto:'.$mail.'"><i class="fas fa-envelope"></i>&nbsp;REGAIA Anthony</a><br>
        <a target=”_blank” class="alink" href="'.$linkedin.'"><i class="fab fa-linkedin"></i>&nbsp;LinkedIn</a><br>
        <a target=”_blank” class="alink" href="'.$facebook.'"><i class="fab fa-facebook-square"></i>&nbsp;Facebook</a>
    </div> 
</footer>
</html>';
}
