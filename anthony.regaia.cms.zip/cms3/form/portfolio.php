<?php

try{
    // se connecter en local ->
    // $db = new PDO('mysql:host=localhost;dbname=regaia', 'root', 'root');

    $db = new PDO('mysql:host=localhost;dbname=regaia;', 'regaia', '4qyk0I4p');
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e){

}

function formPortfolio($db){

    //email perso footer
    $requestMail= 'SELECT personnel from `personnel`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $mail=$linemail['personnel'];

    //linkedin footer
    $requestMail= 'SELECT linkedin from `linkedin`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $linkedin=$linemail['linkedin'];


    //facebook footer
    $requestMail= 'SELECT facebook from `facebook`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $facebook=$linemail['facebook'];

    //lien projet
    $requestSelect='SELECT link FROM `link`';
    $reponseSelect=crudDb($db,$requestSelect);
    $liness = $reponseSelect->fetchAll();

    $content2 = '';
    foreach($liness as $line){
        $content2 .= '<div class="margintop3">';
        $content2 .=  '<a target="_blank" alt="#" class="link-p" href="'. $line['link'].'"><i>Lien du projet</i> <i class="fas fa-external-link-alt"></i></a>';
        $content2 .= '</div>';
    }

    //description
    $requestSelect='SELECT description FROM `description`';
    $reponseSelect=crudDb($db,$requestSelect);
    $linesss= $reponseSelect->fetchAll();

    $content3 = '';
    foreach($linesss as $line){
        $content3 .= '<div class="margintop3">';
        $content3 .=  '<p>'. $line['description'].'</p>';
        $content3 .= '</div>';

    }

//image
    $requestImage='SELECT nom_dossier,nom_fichier,extension FROM `image` where position ="portfolio" ';
    $reponseImage=crudDb($db,$requestImage);
    $lineImage=$reponseImage->fetchAll();

    $j=0;
    // concaténation du content
    $content4 = '';

    for($i=0;$i<count($lineImage);$i++){
        $content4 .='<div class="margin1">';
        $content4 .='<img class="border-img" src="';
        $content4 .= $lineImage[$i]['nom_dossier'].'/'.$lineImage[$i]['nom_fichier'].'.'.$lineImage[$i]['extension'];
        $content4 .= '" alt="#" width="150" height="150"> ';
        $content4 .='</div>';
        $j++;

    }

echo'
    
    <section>
        <div class="container">
            <div class="col col-1-3">
                '.$content4.' 
            </div> 
            <div class="col col-1-3">
                <div class="margintop3bis">
                    '.$content3.' 
                </div>
            </div>
            <div class="col col-1-3 last">
                <div class="margintop3bis">
                    '.$content2.' 
                </div>
             </div> 
             <div class="clear"></div>
                </div>
    </section> 

<footer id="contact">   
    <div class="container">       
        <a class="alink" href="mailto:'.$mail.'"><i class="fas fa-envelope"></i>&nbsp;REGAIA Anthony</a><br>
        <a target=”_blank” class="alink" href="'.$linkedin.'"><i class="fab fa-linkedin"></i>&nbsp;LinkedIn</a><br>
        <a target=”_blank” class="alink" href="'.$facebook.'"><i class="fab fa-facebook-square"></i>&nbsp;Facebook</a>
        </div> 
</footer>
</html>';
}
        
        
      





