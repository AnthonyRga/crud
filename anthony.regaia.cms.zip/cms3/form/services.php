<?php

try{
    // se connecter en local ->
    // $db = new PDO('mysql:host=localhost;dbname=regaia', 'root', 'root');

    $db = new PDO('mysql:host=localhost;dbname=regaia;', 'regaia', '4qyk0I4p');
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e){

}
function formServices($db){

    //image services
    $request='SELECT nom_dossier,nom_fichier,extension FROM `image` where position ="services" ';
    $reponse=crudDb($db,$request);
    $lines=$reponse->fetchAll();

    $j=0;
    // concaténation du content + boucle pour créer une div apres l'affichage de 3images
    $content2 = '';

    for($i=0;$i<count($lines);$i++){
        $content2 .='<div class="col col-1-3">';
        $content2 .='<img class="img-logo" src="';
        $content2 .= $lines[$i]['nom_dossier'].'/'.$lines[$i]['nom_fichier'].'.'.$lines[$i]['extension'];
        $content2 .= '" alt="logo langage" width="150" height="150"> ';
        $content2 .='</div>';
        $j++;
        if ($j%3==0 ){
            $content2 .='<div class="clear"></div>';

        }
    }

    //compétences
    $requestSelect='SELECT competence FROM `competence`';
    $reponse=crudDb($db,$requestSelect);

    $lines = $reponse->fetchAll();
    $content = '<ul>';
    foreach ($lines as $line){

        $content .=  '<p><i class="fas fa-circle"></i>'. $line['competence'].'</p>';

    }
    $content .= '</ul>';


    //mail footer
    $requestMail= 'SELECT personnel from `personnel`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $mail=$linemail['personnel'];

    //linkedin footer
    $requestMail= 'SELECT linkedin from `linkedin`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $linkedin=$linemail['linkedin'];


    //facebook footer
    $requestMail= 'SELECT facebook from `facebook`';
    $reponseMail=  crudDb($db, $requestMail);
    $linemail=$reponseMail->fetch();
    $facebook=$linemail['facebook'];

    echo' 
        <section>
            <div class="container">
                <div class="col col-1-3">
                    <p>Mes compétences : </p>
                    '.$content.' 
                </div>
            <div class="clear"></div>
                <div>
                '.$content2.'        
            </div>
                <div class="clear"></div>
            </div>
        </section>
        
        
<footer id="services">   
    <div class="container">       
        <a class="alink" href="mailto:'.$mail.'"><i class="fas fa-envelope"></i>&nbsp;REGAIA Anthony</a><br>
        <a target=”_blank” class="alink" href="'.$linkedin.'"><i class="fab fa-linkedin"></i>&nbsp;LinkedIn</a><br> 
        <a target=”_blank” class="alink" href="'.$facebook.'"><i class="fab fa-facebook-square"></i>&nbsp;Facebook</a>      
    </div> 
</footer>
</html>';
}
