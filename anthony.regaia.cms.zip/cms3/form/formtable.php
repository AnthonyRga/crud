<?php

try{
    // se connecter en local ->
    // $db = new PDO('mysql:host=localhost;dbname=regaia', 'root', 'root');

    $db = new PDO('mysql:host=localhost;dbname=regaia;', 'regaia', '4qyk0I4p');
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e){

}

//coreUI script bootstrap
echo '<link rel="stylesheet" href="https://unpkg.com/@coreui/coreui/dist/css/coreui.min.css">';
echo '<link rel="stylesheet" href="https://unpkg.com/@coreui/icons/css/coreui-icons.min.css">';
echo '<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>';
echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>';
echo '<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>';
echo '<script src="https://unpkg.com/@coreui/coreui/dist/js/coreui.min.js"></script>';

//font Awesome
echo '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">';

//================= formeTableHome
function formTableHome($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Titre</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Texte</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){

        echo '<tr>';
        echo '<td class="border-bottom">'.$line['titre'].'</td>';
        echo '<td class="border-bottom">'.$line['texte'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=home&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}

//================= formeTableAge
function formTableAge($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Age</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['age'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=age&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//================= formeTableCommune
function formTableCommune($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Commune</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['commune'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=commune&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}

//================= formeTablePresentation
function formTablePresentation($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Présentation</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['presentation'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=presentation&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}

//================= formeTableHobbys
function formTableHobbys($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Mes hobbys</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Delete</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['hobbys'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=hobbys&action=update&id='.$line['id'].'">Update</a></td>';
        echo '<td class="border-bottom"><a class="text-danger" href="?table=hobbys&action=delete&id='.$line['id'].'">Delete</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//================= formeTablePerso Email
function formTablePerso($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">E-mail</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['personnel'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=personnel&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//================= formeTableLinked footer
function formTableLinked($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">LinkedIn</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['linkedin'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=linkedin&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//================= formeTableFace footer
function formTableFace($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Facebook</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['facebook'].'</td>';
        echo '<td class="border-bottom text-success"><a class="text-success" href="?table=facebook&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//================= formeTableComp
function formTableComp($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Compétence(s)</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Delete</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['competence'].'</td>';
        echo '<td class="border-bottom"><a class="text-success" href="?table=competence&action=update&id='.$line['id'].'">Update</a></td>';
        echo '<td class="border-bottom"><a class="text-danger" href="?table=competence&action=delete&id='.$line['id'].'">Delete</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//================= formTableContact
function formTableContact($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Nom</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Email</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Message</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Delete</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['nom'].'</td>';
        echo '<td class="border-bottom">'.$line['prenom'].'</td>';
        echo '<td class="border-bottom">'.$line['message'].'</td>';
        echo '<td class="border-bottom"><a class="text-danger" href="?table=contact&action=delete&id='.$line['id'].'">Delete</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//============== formTableImage
function formTableImage($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Nom dossier</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Nom fichier</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Extension</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Quelle page?</td>';
    echo '<p class="h4">Gestion des images logo page Compétences (services)</p>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white"> Image</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Delete</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){

        echo '<tr>';
        //echo '<td class="border-bottom">'.$line['nom_dossier'].'</td>';
        //echo '<td class="border-bottom">'.$line['nom_fichier'].'</td>';
        //echo '<td class="border-bottom">'.$line['extension'].'</td>';
        //echo '<td class="border-bottom">'.$line['position'].'</td>';
        echo '<td><img class="border" style="width:5%;height:5%;" alt="#" src="https://regaia.bes-webdeveloper-seraing.be/cms3/'.$line['nom_dossier'].'/'.$line['nom_fichier'].'.'.$line['extension'].'"</img></td>';
        echo '<td><a class="text-success" href="?table=image&action=update&id='.$line['id'].'">Update</a></td>';
        echo '<td><a class="text-danger" href="?table=image&action=delete&id='.$line['id'].'">Delete</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//============== formTableImagePresentation
function formTableImagePresentation($lines){
    echo '<p class="h4">Gestion des 3 images sur la page Présentation</p>';
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Nom dossier</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Nom fichier</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Extension</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Quelle page?</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white"> Image</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){

        echo '<tr>';
        //echo '<td class="border-bottom">'.$line['nom_dossier'].'</td>';
        //echo '<td class="border-bottom">'.$line['nom_fichier'].'</td>';
        //echo '<td class="border-bottom">'.$line['extension'].'</td>';
        //echo '<td class="border-bottom">'.$line['position'].'</td>';
        echo '<td><img class="border" style="width:5%;height:5%;" alt="#" src="https://regaia.bes-webdeveloper-seraing.be/cms3/'.$line['nom_dossier'].'/'.$line['nom_fichier'].'.'.$line['extension'].'"</img></td>';

        echo '<td><a class="text-success" href="?table=image&action=update&id='.$line['id'].'">Update</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//================= formeTablePortfolio
function formTablePortfolio($lines){
    echo '<a class="h3 text-dark" href="?table=image&action=insert"><a href="?table=description&action=insert"><a class="h3 bg-info border" style="text-decoration:none;margin-bottom:10px;" href="?table=link&action=insert">Ajouter un Projet </a></a></a>';
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Lien projet</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Delete</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['link'].'</td>';
        echo '<td class="border-bottom"><a class="text-danger" href="?table=link&action=delete&id='.$line['id'].'">Delete</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}

//================= formeTableDescription
function formTableDescription($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';;
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Description projet</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Update</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Delete</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){
        echo '<tr>';
        echo '<td class="border-bottom">'.$line['description'].'</td>';
        echo '<td class="border-bottom"><a class="text-success" href="?table=description&action=update&id='.$line['id'].'">Update</a></td>';
        echo '<td class="border-bottom"><a class="text-danger" href="?table=description&action=delete&id='.$line['id'].'">Delete</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}
//============== formTableImagePortfolio
function formTableImagePortfolio($lines){
    echo '<table class="table">';
    echo '<thead class="thead-dark">';
    //echo '<td style="display:none;" class="p-3 mb-2 bg-light bg-dark text-white" scope="col">ID</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Nom dossier</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Nom fichier</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Extension</td>';
    //echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Quelle page?</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white"> Image</td>';
    echo '<td class="p-3 mb-2 bg-light bg-dark text-white" scope="col">Delete</td>';
    echo '</thead>';
    echo '<tbody>';
    foreach ($lines as $line){

        echo '<tr>';
        //echo '<td style="display:none;" class="bg-secondary border border-dark">'.$line['id'].'</td>';
        //echo '<td class="border-bottom">'.$line['nom_dossier'].'</td>';
        //echo '<td class="border-bottom">'.$line['nom_fichier'].'</td>';
        //echo '<td class="border-bottom">'.$line['extension'].'</td>';
        //echo '<td class="border-bottom">'.$line['position'].'</td>';
        echo '<td><img class="border" style="width:5%;height:5%;" alt="#" src="https://regaia.bes-webdeveloper-seraing.be/cms3/'.$line['nom_dossier'].'/'.$line['nom_fichier'].'.'.$line['extension'].'"</img></td>';
        echo '<td><a class="text-danger" href="?table=link&action=delete&id='.$line['id'].'">Delete</a></td>';
        echo '</tr>';
    }
    echo '<tbody>';
    echo '</table>';
}