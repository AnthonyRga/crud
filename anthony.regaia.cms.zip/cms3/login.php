<?php
session_start();
try{
    // se connecter en local ->
    // $db = new PDO('mysql:host=localhost;dbname=regaia', 'root', 'root');

    $db = new PDO('mysql:host=localhost;dbname=regaia;', 'regaia', '4qyk0I4p');
    $db->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}
catch(PDOException $e){

}

include_once 'form/adminform.php';
include_once 'form/formtable.php';
include_once 'loginverif.php';


// Contenu afficher si l'utilisateur est connecté
function displayProtectedContent($db)
{

    //coreUI script bootstrap
    echo '<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>';
    echo '<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>';
    echo '<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>';
    echo '<script src="https://unpkg.com/@coreui/coreui/dist/js/coreui.min.js"></script>';
    echo '<link rel="stylesheet" href="https://unpkg.com/@coreui/coreui/dist/css/coreui.min.css">';
    echo '<link rel="stylesheet" href="https://unpkg.com/@coreui/icons/css/coreui-icons.min.css">';

    //font Awesome
    echo '<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">';

    // Header Admin
    echo '<div class="text-white bg-dark">';
    echo '<p class="d-inline h2">CMS</p>';
    echo '<br>';
    echo '</div>';

    echo '<div class="text-white" style="background-color:#cb132c;">';
    echo '<a target="_blank" class="d-inline text-white" style="text-decoration:none;margin-left:20px;" href="https://regaia.bes-webdeveloper-seraing.be/cms3/"><i class="fas fa-sign-out-alt"></i>&nbsp;Voir site</a>';
    echo '<a class="d-inline text-white" style="text-decoration:none;margin-left:20px;" href="?logout=1""><i class="fas fa-times"></i>&nbsp;Déconnexion</a>';
    echo '</div>';

    // Menu
    echo' <div class="row">';

    // Administration Footer
    echo'<div class="card" style="width: 18rem;margin-left:30px;margin-top:15px;">';
    echo'<div class="col">';
    echo'<ul class="nav flex-column">';
    echo'<p class="text-center">Administration du Footer</p>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link active bg-info border border-white" href="?table=personnel">Modifier e-mail</a>';
    echo'</li>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link bg-info border border-white" href="?table=linkedin">Modifier LinkedIN</a>';
    echo'</li>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link bg-info border border-white" href="?table=facebook">Modifier Facebook</a>';
    echo'</li>';
    echo'</ul>';
    echo'</div>';
    echo'</div>';

    // Administration de la page Home
    echo'<div class="card" style="width: 18rem;margin-left:10px;margin-top:15px;">';
    echo'<div class="col">';
    echo'<ul class="nav flex-column">';
    echo'<p class="text-center">Administration de la page Home</p>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link active bg-info border border-white" href="?table=home">Modifier titre et texte</a>';
    echo'</li>';
    echo'</div>';
    echo'</div>';

    // Administration de la page Qui suis-je
    echo'<div class="card" style="width: 18rem;margin-left:10px;margin-top:15px;">';
    echo'<div class="col">';
    echo'<ul class="nav flex-column">';
    echo'<p class="text-center">Administration de la page Qui suis-je</p>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link active bg-info border border-white" href="?table=age">Modifier âge</a>';
    echo'</li>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link bg-info border border-white" href="?table=commune">Modifier commune</a>';
    echo'</li>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link bg-info border border-white" href="?table=presentation">Modifier présentation</a>';
    echo'</li>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link bg-info border border-white" href="?table=hobbys">Modifier - Ajouter - Supprimer hobby</a>';
    echo'</li>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link bg-info border border-white" href="?table=image">Gestion Images</a><br>';
    echo'</li>';
    echo'</ul>';
    echo'</div>';
    echo'</div>';

    // Administration de la page Compétences
    echo'<div class="card" style="width: 18rem;margin-left:10px;margin-top:15px;">';
    echo'<div class="col">';
    echo'<ul class="nav flex-column">';
    echo'<p class="text-center">Administration de la page Compétences</p>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link active bg-info border border-white" href="?table=competence">Modifier - Ajouter - Supprimer compétence</a>';
    echo'</li>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link bg-info border border-white" href="?table=image">Gestion Images</a>';
    echo'</li>';
    echo'</div>';
    echo'</div>';

    // Administration de la page Réalisations
    echo'<div class="card" style="width: 18rem;margin-left:10px;margin-top:15px;">';
    echo'<div class="col">';
    echo'<ul class="nav flex-column">';
    echo'<p class="text-center">Administration de la page Réalisations</p>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link active bg-info border border-white" href="?table=link">Gestion Projets</a>';
    echo'</li>';
    echo'</div>';
    echo'</div>';

    // Administration de la page Contact
    echo'<div class="card" style="width: 18rem;margin-left:10px;margin-top:15px;">';
    echo'<div class="col">';
    echo'<ul class="nav flex-column">';
    echo'<p class="text-center">Administration de la page Contact</p>';
    echo'<li class="nav-item">';
    echo'<a class="nav-link active bg-info border border-white" href="?table=contact">Administration des messages</a>';
    echo'</li>';
    echo'</div>';
    echo'</div>';

    echo'</div>';


    $table = filter_input(INPUT_GET, "table", FILTER_SANITIZE_STRING);


        //====================== Si on clique sur Home ====================//
        if ($table == 'home') {

            // Affichage de la table
            $requestSelect = 'SELECT * FROM `home`';
            $reponse = crudDb($db, $requestSelect);

            $lines = $reponse->fetchAll();

            formTableHome($lines);

    // Insérer titre texte - Home
            $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
            if ($action == "insert") {
                formHome();
                $titre = filter_input(INPUT_POST, "titre", FILTER_SANITIZE_STRING);
                $texte = filter_input(INPUT_POST, "texte", FILTER_SANITIZE_STRING);
                if (!empty($titre && $texte)) {
                    $request = "INSERT INTO `home`(`titre`,`texte`) VALUES (:titre,:texte)";

                    crudDb($db, $request, ['titre' => $_POST['titre'], 'texte' => $_POST['texte']]);
                    header('Location: login.php?table=home');
                }

            }
    // Update titre texte - Home
            if ($action == "update") {

                formHome();
                $titre = filter_input(INPUT_POST, "titre", FILTER_SANITIZE_STRING);
                $texte = filter_input(INPUT_POST, "texte", FILTER_SANITIZE_STRING);
                if (!empty($titre && $texte)) {
                    $request = 'UPDATE `home` SET `titre` = :titre,`texte` = :texte WHERE `id` = :id';
                    crudDb($db, $request, ['titre' => $_POST['titre'], 'texte' => $_POST['texte'], 'id' => $_GET['id']]);
                    header('Location: login.php?table=home');

                }

            }


        }
        //------------------------------------------------------------------------
        //====================== Si on clique sur Age ====================//
        if ($table == 'age') {

            // Affichage de la table
            $requestSelect = 'SELECT * FROM `age`';
            $reponse = crudDb($db, $requestSelect);
            $lines = $reponse->fetchAll();
            formTableAge($lines);


            // Insérer âge - Qui suis je
            $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
            if ($action == "insert") {
                formAge();
                $age = filter_input(INPUT_POST, "age", FILTER_SANITIZE_STRING);
                if (!empty($age)) {
                    $request = "INSERT INTO `age`(`age`) VALUES (:age)";

                    crudDb($db, $request, ['age' => $_POST['age']]);
                    header('Location: login.php?table=age');
                }

            }

            // Update age - Qui suis-je
            if ($action == "update") {
                formAge();
                $age = filter_input(INPUT_POST, "age", FILTER_SANITIZE_STRING);
                if (!empty($age)) {
                    $request = 'UPDATE `age` SET `age` = :age WHERE `id` = :id';
                    crudDb($db, $request, ['age' => $_POST['age'], 'id' => $_GET['id']]);
                    header('Location: login.php?table=age');
                }
            }
        }
        //====================== Si on clique sur Commune ====================//
        if ($table == 'commune') {

            // Affichage de la table
            $requestSelect = 'SELECT * FROM `commune`';
            $reponse = crudDb($db, $requestSelect);
            $lines = $reponse->fetchAll();
            formTableCommune($lines);


            // Insérer commune - Qui suis-je
            $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
            if ($action == "insert") {
                formCommune();
                $titre = filter_input(INPUT_POST, "commune", FILTER_SANITIZE_STRING);
                if (!empty($commune)) {
                    $request = "INSERT INTO `commune`(`commune`) VALUES (:commune)";
                    crudDb($db, $request, ['commune' => $_POST['commune']]);
                    header('Location: login.php?table=commune');
                }

            }

            // Update commune - Qui suis-je
            if ($action == "update") {
                formCommune();
                $commune = filter_input(INPUT_POST, "commune", FILTER_SANITIZE_STRING);
                if (!empty($commune)) {
                    $request = 'UPDATE `commune` SET `commune` = :commune WHERE `id` = :id';
                    crudDb($db, $request, ['commune' => $_POST['commune'], 'id' => $_GET['id']]);
                    header('Location: login.php?table=commune');
                }
            }
        }
    //====================== Si on clique sur Changer présentation ====================//
    if ($table == 'presentation') {

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `presentation`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTablePresentation($lines);


        // Insérer une présentation - Qui suis-je
        $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
        if ($action == "insert") {
            formPresentation();
            $presentation = filter_input(INPUT_POST, "presentation", FILTER_SANITIZE_STRING);
            if (!empty($presentation)) {
                $request = "INSERT INTO `presentation`(`presentation`) VALUES (:presentation)";
                crudDb($db, $request, ['presentation' => $_POST['presentation']]);
                header('Location: login.php?table=presentation');
            }

        }

        // Update présentation - Qui suis-je
        if ($action == "update") {
            formPresentation();
            $presentation = filter_input(INPUT_POST, "presentation", FILTER_SANITIZE_STRING);
            if (!empty($presentation)) {
                $request = 'UPDATE `presentation` SET `presentation` = :presentation WHERE `id` = :id';
                crudDb($db, $request, ['presentation' => $_POST['presentation'], 'id' => $_GET['id']]);
                header('Location: login.php?table=presentation');
            }
        }
    }

    //====================== Si on clique sur Hobbys  ====================//
    if ($table == 'hobbys') {

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `hobbys`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTableHobbys($lines);

        // Message insérer hobby
        echo '<a class="h3 bg-info border" style="text-decoration:none;margin-bottom:10px;" href="?table=hobbys&action=insert"> Voulez-vous ajouter un hobby?</a> <br>';


        // Insérer des hobbys - Qui suis-je
        $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
        if ($action == "insert") {
            formHobbys();
            $hobbys = filter_input(INPUT_POST, "hobbys", FILTER_SANITIZE_STRING);
            if (!empty($hobbys)){
                $request = "INSERT INTO `hobbys`(`hobbys`) VALUES (:hobbys)";

                crudDb($db, $request,['hobbys'=>$_POST['hobbys']]);
                header('Location: login.php?table=hobbys');
            }

        }

        // Update hobbys - Qui suis-je
        if ($action == "update") {
            formHobbys2();
            $hobbys= filter_input(INPUT_POST, "hobbys", FILTER_SANITIZE_STRING);
            if (!empty($hobbys)) {
                $request = 'UPDATE `hobbys` SET `hobbys` = :hobbys WHERE `id` = :id';
                crudDb($db, $request, ['hobbys' => $_POST['hobbys'], 'id' => $_GET['id']]);
                header('Location: login.php?table=hobbys');
            }
        }

        // Delete un hobby
        if ($action == "delete") {
            $request = 'DELETE FROM `hobbys` WHERE `id` = :id';
            crudDb($db, $request, ['id' => $_GET['id']]);
            header('Location: login.php?table=hobbys');
        }
    }

    //====================== Si on clique sur email ====================//
    if ($table == 'personnel') {

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `personnel`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTablePerso($lines);


        // Insérer email - footer
        $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
        if ($action == "insert") {
            formPerso();
            $personnel = filter_input(INPUT_POST, "personnel", FILTER_SANITIZE_STRING);
            if (!empty($personnel)) {
                $request = "INSERT INTO `personnel`(`personnel`) VALUES (:personnel)";

                crudDb($db, $request, ['personnel' => $_POST['personnel']]);
                header('Location: login.php?table=personnel');
            }

        }

        // Update email - footer
        if ($action == "update") {
            formPerso();
            $personnel = filter_input(INPUT_POST, "personnel", FILTER_SANITIZE_STRING);
            if (!empty($personnel)) {
                $request = 'UPDATE `personnel` SET `personnel` = :personnel WHERE `id` = :id';
                crudDb($db, $request, ['personnel' => $_POST['personnel'], 'id' => $_GET['id']]);
                header('Location: login.php?table=personnel');
            }
        }
    }
    //====================== Si on clique sur linkedin ====================//
    if ($table == 'linkedin') {

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `linkedin`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTableLinked($lines);


        // Insérer linkedin - footer
        $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
        if ($action == "insert") {
            formLinked();
            $linkedin = filter_input(INPUT_POST, "linkedin", FILTER_SANITIZE_STRING);
            if (!empty($linkedin)) {
                $request = "INSERT INTO `linkedin`(`linkedin`) VALUES (:linkedin)";
                crudDb($db, $request, ['linkedin' => $_POST['linkedin']]);
                header('Location: login.php?table=linkedin');
            }

        }

        // Update linkedin footer
        if ($action == "update") {
            formLinked();
            $linkedin = filter_input(INPUT_POST, "linkedin", FILTER_SANITIZE_STRING);
            if (!empty($linkedin)) {
                $request = 'UPDATE `linkedin` SET `linkedin` = :linkedin WHERE `id` = :id';
                crudDb($db, $request, ['linkedin' => $_POST['linkedin'], 'id' => $_GET['id']]);
                header('Location: login.php?table=linkedin');
            }
        }
    }
    //====================== Si on clique sur facebook ====================//
    if ($table == 'facebook') {

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `facebook`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTableFace($lines);


        // Insérer facebook - footer
        $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
        if ($action == "insert") {
            formFace();
            $facebook = filter_input(INPUT_POST, "facebook", FILTER_SANITIZE_STRING);
            if (!empty($facebook)) {
                $request = "INSERT INTO `facebook`(`facebook`) VALUES (:facebook)";
                crudDb($db, $request, ['facebook' => $_POST['facebook']]);
                header('Location: login.php?table=facebook');
            }

        }

        // Update facebook footer
        if ($action == "update") {
            formFace();
            $facebook = filter_input(INPUT_POST, "facebook", FILTER_SANITIZE_STRING);
            if (!empty($facebook)) {
                $request = 'UPDATE `facebook` SET `facebook` = :facebook WHERE `id` = :id';
                crudDb($db, $request, ['facebook' => $_POST['facebook'], 'id' => $_GET['id']]);
                header('Location: login.php?table=facebook');
            }
        }
    }

    //====================== Si on clique sur Compétences  ====================//
    if ($table == 'competence') {

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `competence`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTableComp($lines);

        // Demander insérer compétence
        echo '<a class="h3 bg-info border" style="text-decoration:none;margin-bottom:10px;" href="?table=competence&action=insert">Voulez-vous ajouter une compétence?</a> <br>';


        // Insérer une compétence - Services
        $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
        if ($action == "insert") {
            formComp();
            $competence = filter_input(INPUT_POST, "competence", FILTER_SANITIZE_STRING);
            if (!empty($competence)){
                $request = "INSERT INTO `competence`(`competence`) VALUES (:competence)";
                crudDb($db, $request,['competence'=>$_POST['competence']]);
                header('Location: login.php?table=competence');
            }

        }

        // Update compétence - Services
        if ($action == "update") {
            formComp2();
            $competence= filter_input(INPUT_POST, "competence", FILTER_SANITIZE_STRING);
            if (!empty($competence)) {
                $request = 'UPDATE `competence` SET `competence` = :competence WHERE `id` = :id';
                crudDb($db, $request, ['competence' => $_POST['competence'], 'id' => $_GET['id']]);
                header('Location: login.php?table=competence');
            }
        }

        // Delete une compétence
        if ($action == "delete") {
            $request = 'DELETE FROM `competence` WHERE `id` = :id';
            crudDb($db, $request, ['id' => $_GET['id']]);
            header('Location: login.php?table=competence');
        }
    }
    //====================== Si on clique sur Contact ====================//
     if ($table == 'contact') {
        $action = filter_input(INPUT_GET,"action",FILTER_SANITIZE_STRING);

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `contact`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTableContact($lines);


        // Supprimer un message
        if ($action== "delete") {
            $request= 'DELETE FROM `contact` WHERE `id` = :id';
            crudDb($db,$request,['id'=>$_GET['id']]);
            header('Location: login.php?table=contact');
        }
    }

//--------------------------------------------------

// Si on clique sur les images
    if ($table == 'image') {
        $action = filter_input(INPUT_GET,"action",FILTER_SANITIZE_STRING);
        echo '<a class="h3 bg-info border" style="text-decoration:none;margin-bottom:10px;" href="?table=image&action=insert">Ajouter une image</a> <br>';
// Insérer une image
        if ($action== "insert") {
            formImage();
            $nom_dossier = filter_input(INPUT_POST,"nom_dossier",FILTER_SANITIZE_STRING);
            $nom_fichier = filter_input(INPUT_POST,"nom_fichier",FILTER_SANITIZE_STRING);
            $extension = filter_input(INPUT_POST,"extension",FILTER_SANITIZE_STRING);
            $position = filter_input(INPUT_POST,"position",FILTER_SANITIZE_STRING);
            if (!empty($nom_dossier && $nom_fichier && $extension && $position )) {
                $fileSizeEnMega = 2;
                $maxFileSize = $fileSizeEnMega *1000000;
                $allowedExtensions = ['jpg'=>"img/jpeg",'jpeg'=>"img/jpeg",'png'=>"img/png",'gif'=>"img/gif"];
                if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0){
                    if ($_FILES['avatar']['size'] <= $maxFileSize){
                        $pathInfo = pathinfo($_FILES['avatar']['name']);

                        $extension2 = $pathInfo['extension'];
                        if (array_key_exists($extension2,$allowedExtensions) && mime_content_type($_FILES['avatar']['tmp_name']) == $allowedExtensions[$extension2] && $extension==$extension2){

                            $uploadedFilePath = './'.$nom_dossier.'/'.$nom_fichier.'.'.$extension2;
                            move_uploaded_file($_FILES['avatar']['tmp_name'],$uploadedFilePath);

                        }

                    }
                    else{
                        echo 'fichier trop gros';
                    }

                }
                if ($extension==$extension2) {
                    $request = "INSERT INTO `image`(`nom_dossier`,`nom_fichier`,`extension`,`position`) VALUES (:nom_dossier,:nom_fichier,:extension,:position)";

                    crudDb($db, $request, ['nom_dossier' => $_POST['nom_dossier'], 'nom_fichier' => $_POST['nom_fichier'], 'extension' => $_POST['extension'], 'position' => $_POST['position']]);
                    header('Location: login.php?table=image');
                }
                else{
                    echo 'Extension différente';
                }
            }
            else{
            }
        }

        $requestSelect='SELECT * FROM `image` WHERE position = "presentation"';
        $reponse=crudDb($db,$requestSelect);
        $lines = $reponse->fetchAll();

        $requestSelect='SELECT * FROM `image` WHERE position = "services"';
        $reponse=crudDb($db,$requestSelect);
        $linesS = $reponse->fetchAll();

        formTableImagePresentation($lines);
        formTableImage($linesS);

// Update une image
        if ($action== "update" ){

            formImage();
            $nom_dossier = filter_input(INPUT_POST,"nom_dossier",FILTER_SANITIZE_STRING);
            $nom_fichier = filter_input(INPUT_POST,"nom_fichier",FILTER_SANITIZE_STRING);
            $extension = filter_input(INPUT_POST,"extension",FILTER_SANITIZE_STRING);
            $position = filter_input(INPUT_POST,"position",FILTER_SANITIZE_STRING);
            if (!empty($nom_dossier && $nom_fichier && $extension && $position)) {
                $request="UPDATE `image` SET `nom_dossier` = :nom_dossier , `nom_fichier` =  :nom_fichier, `extension` = :extension, `position` = :position WHERE `id` = :id";
                crudDb($db,$request,['nom_dossier'=>$_POST['nom_dosssier'],'nom_fichier'=>$_POST['nom_fichier'],'extension'=>$_POST['extension'],'position'=>$_POST['position'],'id'=>$_GET['id']]);
                header('Location: login.php?table=image');
            }
            else{
            }
        }
// Delete une image
        if ($action== "delete") {
            $request= 'DELETE FROM `image` WHERE `id` = :id';
            crudDb($db,$request,['id'=>$_GET['id']]);
            header('Location: login.php?table=image');
        }

    }
//----------------------------------------------------
    //====================== Si on clique sur Portfolio/réalisation  ====================//
    if ($table == 'link') {

        // Affichage de la table
        $requestSelect = 'SELECT * FROM `link`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTablePortfolio($lines);

        // Affichage de la table image portfolio
        $requestSelect='SELECT * FROM `image` WHERE position = "portfolio"';
        $reponse=crudDb($db,$requestSelect);
        $lines = $reponse->fetchAll();
        formTableImagePortfolio($lines);

        // Affichage de la description
        $requestSelect = 'SELECT * FROM `description`';
        $reponse = crudDb($db, $requestSelect);
        $lines = $reponse->fetchAll();
        formTableDescription($lines);

        // Insérer un lien - image - description
        $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
        if ($action == "insert") {
            formLink();
            $link = filter_input(INPUT_POST, "link", FILTER_SANITIZE_STRING);
            if (!empty($link)){
                $request = "INSERT INTO `link`(`link`) VALUES (:link)";
                crudDb($db, $request,['link'=>$_POST['link']]);
                header('Location: login.php?table=link');
            }
            $nom_dossier = filter_input(INPUT_POST,"nom_dossier",FILTER_SANITIZE_STRING);
            $nom_fichier = filter_input(INPUT_POST,"nom_fichier",FILTER_SANITIZE_STRING);
            $extension = filter_input(INPUT_POST,"extension",FILTER_SANITIZE_STRING);
            $position = filter_input(INPUT_POST,"position",FILTER_SANITIZE_STRING);
            if (!empty($nom_dossier && $nom_fichier && $extension && $position )) {
                $fileSizeEnMega = 2;
                $maxFileSize = $fileSizeEnMega *1000000;
                $allowedExtensions = ['jpg'=>"img/jpeg",'jpeg'=>"img/jpeg",'png'=>"img/png",'gif'=>"img/gif"];
                if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0){
                    if ($_FILES['avatar']['size'] <= $maxFileSize){
                        $pathInfo = pathinfo($_FILES['avatar']['name']);

                        $extension2 = $pathInfo['extension'];
                        if (array_key_exists($extension2,$allowedExtensions) && mime_content_type($_FILES['avatar']['tmp_name']) == $allowedExtensions[$extension2] && $extension==$extension2){
                            $uploadedFilePath = './'.$nom_dossier.'/'.$nom_fichier.'.'.$extension2;
                            move_uploaded_file($_FILES['avatar']['tmp_name'],$uploadedFilePath);
                        }
                    }
                    else{
                        echo 'fichier trop gros';
                    }

                }
                if ($extension==$extension2) {
                    $request = "INSERT INTO `image`(`nom_dossier`,`nom_fichier`,`extension`,`position`) VALUES (:nom_dossier,:nom_fichier,:extension,:position)";

                    crudDb($db, $request, ['nom_dossier' => $_POST['nom_dossier'], 'nom_fichier' => $_POST['nom_fichier'], 'extension' => $_POST['extension'], 'position' => $_POST['position']]);

                }
                else{
                    echo 'Extension différente';
                }

            }
            else{

            }
            $description = filter_input(INPUT_POST, "description", FILTER_SANITIZE_STRING);
            if (!empty($description)) {
                $request = "INSERT INTO `description`(`description`) VALUES (:description)";
                crudDb($db, $request, ['description' => $_POST['description']]);
                header('Location: login.php?table=link');

            }
        }

        // Update projet portfolio
        if ($action == "update") {
            formLink();
            $link= filter_input(INPUT_POST, "link", FILTER_SANITIZE_STRING);
            if (!empty($link)) {
                $request = 'UPDATE `link` SET `link` = :link WHERE `id` = :id';
                crudDb($db, $request, ['link' => $_POST['link'], 'id' => $_GET['id']]);
            }
            $nom_dossier = filter_input(INPUT_POST,"nom_dossier",FILTER_SANITIZE_STRING);
            $nom_fichier = filter_input(INPUT_POST,"nom_fichier",FILTER_SANITIZE_STRING);
            $extension = filter_input(INPUT_POST,"extension",FILTER_SANITIZE_STRING);
            $position = filter_input(INPUT_POST,"position",FILTER_SANITIZE_STRING);
            if (!empty($nom_dossier && $nom_fichier && $extension && $position)) {
                $request="UPDATE `image` SET `nom_dossier` = :nom_dossier , `nom_fichier` =  :nom_fichier, `extension` = :extension, `position` = :position WHERE `id` = :id";
                crudDb($db,$request,['nom_dossier'=>$_POST['nom_dosssier'],'nom_fichier'=>$_POST['nom_fichier'],'extension'=>$_POST['extension'],'position'=>$_POST['position'],'id'=>$_GET['id']]);
                header('Location: login.php?table=link');
            }
            else{

            }
            $description = filter_input(INPUT_POST, "description", FILTER_SANITIZE_STRING);
            if (!empty($description)) {
                $request = 'UPDATE `description` SET `description` = :description WHERE `id` = :id';
                crudDb($db, $request, ['description' => $_POST['description']]);

            }
        }

        // Delete projet portfoio
        if ($action == "delete") {
            $request = 'DELETE FROM `link` WHERE `id` = :id';
            crudDb($db, $request, ['id' => $_GET['id']]);
            $request= 'DELETE FROM `image` WHERE `id` = :id';
            crudDb($db,$request,['id'=>$_GET['id']]);
            $request= 'DELETE FROM `description` WHERE `id` = :id';
            crudDb($db,$request,['id'=>$_GET['id']]);
        }
    }
    //====================== Table description ====================//
    $action = filter_input(INPUT_GET, "action", FILTER_SANITIZE_STRING);
    if ($table == 'description') {

        // Update
        if ($action == "update") {
            formDescription();
            $description = filter_input(INPUT_POST, "description", FILTER_SANITIZE_STRING);
            if (!empty($description)) {
                $request = 'UPDATE `description` SET `description` = :description WHERE `id` = :id';
                crudDb($db, $request, ['description' => $_POST['description'], 'id' => $_GET['id']]);
                header('Location: login.php?table=description');
            }
        }// Delete
        if ($action== "delete") {
            $request= 'DELETE FROM `description` WHERE `id` = :id';
            crudDb($db,$request,['id'=>$_GET['id']]);
            header('Location: login.php?table=description');
        }
    }
}
//-----------------------------------------------------------
    function crudDb(PDO $db, $request, $params = [])
    {
        try {
            $reponse = $db->prepare($request);
            $reponse->execute($params);
        } catch (Exception $ex) {

        }
        return $reponse;
    }

